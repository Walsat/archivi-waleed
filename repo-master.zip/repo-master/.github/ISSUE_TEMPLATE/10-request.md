---
name: 软件打包请求
about: package request

---

### 问题类型 / Type of issues

* 软件打包请求 / package request

----

* 简述 / Brief Description

    （请在此填写）

* 主要语言和工具链 / Main Languages and Toolchains

    （请在此填写）

* 上游链接 / Upstream Link

    （请在此填写）

* 为何需要这个软件包 / Why Need This Package

    （请在此填写）
