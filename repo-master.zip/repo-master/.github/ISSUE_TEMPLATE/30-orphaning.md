---
name: 弃置软件包
about: orphaning packages

---

### 问题类型 / Type of issues

* 弃置软件包 / orphaning packages

### 受影响的软件包 / Affected packages

* （请在此填写包名，每行一个，开头加上星号 / package names, one per line）

----
