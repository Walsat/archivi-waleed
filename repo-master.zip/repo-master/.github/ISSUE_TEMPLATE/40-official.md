---
name: 软件包被官方仓库收录
about: available in official repos

---

### 问题类型 / Type of issues

* 软件包被官方仓库收录 / available in official repos

### 受影响的软件包 / Affected packages

* （请在此填写包名，每行一个，开头加上星号 / package names, one per line）

----
