---
name: 其它问题
about: other

---

### 问题类型 / Type of issues

* 其它 / other

### 受影响的软件包 / Affected packages

* （请在此填写包名，每行一个，开头加上星号 / package names, one per line）

----

请在此补充说明。
Please describe in detail here.
