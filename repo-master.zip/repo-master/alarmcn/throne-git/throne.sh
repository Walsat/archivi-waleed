#!/bin/bash

exec /usr/lib/throne/Throne -appdata "$@"
