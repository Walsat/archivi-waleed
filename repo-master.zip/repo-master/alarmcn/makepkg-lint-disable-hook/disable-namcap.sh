#!/bin/sh

cat > /usr/bin/namcap <<EOF
#!/bin/bash
exit 0
EOF

chmod +x /usr/bin/namcap
