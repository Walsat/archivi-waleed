#!/bin/bash

export _portableConfig=moe.launcher.an-anime-game-launcher
portable -- $@